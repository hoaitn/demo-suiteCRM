<?php
// created: 2016-05-12 11:22:39
$mod_strings = array (
  'LBL_STANDARDISED_ADDRESS_QSOFT_STANDARDISED_ADDRESSES_ID' => 'standardised address (related  ID)',
  'LBL_STANDARDISED_ADDRESS' => 'Standardised Address',
  'LBL_DETAILVIEW_PANEL1' => 'Map',
  'LBL_CONTACTSMAP' => 'Location',
);