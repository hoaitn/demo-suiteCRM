<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2016-05-16 05:58:18
$dictionary['Account']['fields']['contactsmap_c']['inline_edit']='1';
$dictionary['Account']['fields']['contactsmap_c']['labelValue']='Location';

 

 // created: 2016-05-10 10:44:48
$dictionary['Account']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 

 // created: 2016-05-10 10:44:48
$dictionary['Account']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 

 // created: 2016-05-10 10:44:47
$dictionary['Account']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 

 // created: 2016-05-10 10:44:47
$dictionary['Account']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 

 // created: 2016-05-12 10:57:40
$dictionary['Account']['fields']['qsoft_standardised_addresses_id_c']['inline_edit']=1;

 

 // created: 2016-05-12 11:02:23
$dictionary['Account']['fields']['standardised_address_c']['inline_edit']='1';
$dictionary['Account']['fields']['standardised_address_c']['labelValue']='Standardised Address';

 
?>